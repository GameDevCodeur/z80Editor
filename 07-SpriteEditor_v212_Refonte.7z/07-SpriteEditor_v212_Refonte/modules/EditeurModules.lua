--
-- Modules
--

require "modules.CPC"

--
require "modules.buttons.BOUTTON"
--

--
require "modules.PALETTE"
require "modules.GRILLE"

--
require "modules.buttons.BTSAVE"
require "modules.buttons.BTLOAD"

--
require "modules.VIEWER"
require "modules.HASCENSOR"
require "modules.VASCENSOR"

