--
--  BOUTTON
--

BOUTTON = {}

BOUTTON.POSITION	= {x=0, y=0}

BOUTTON.HANDCURSOR 	= LM.getSystemCursor("hand")
BOUTTON.BOXSIZE 	= 32
--
BOUTTON.LINE		= {1,1,1,1}
----
BOUTTON.TEXT		= ""
BOUTTON.TEXTOVER	= ""
BOUTTON.TEXTCOLOR  	= LG.setColor(1,1,1,1)
--
BOUTTON.SELECTED	= false
--
BOUTTON.IMAGE		= nil
BOUTTON.IMAGECOLOR	= {1,1,1,1}

--
BOUTTON.New = function(pos, text, imagePath, callBack)
--
	local loadTransparent = function(imagePath, transR, transG, transB)
	--
		--
		imageData = LI.newImageData(imagePath ) 
		--
		function mapFunction(x, y, r, g, b, a)
		--
			--
			if r == transR and g == transG and b == transB then a = 0 end
			--
			return r,g,b,a
			--
		--
		end
		--
		imageData:mapPixel( mapFunction )
		--
		return LG.newImage( imageData )
	--
	end

    return setmetatable(
						{
							POSITION	= pos,
							TEXT 		= text,							
							onClick 	= (callBack == nil) and BOUTTON.onClick or callBack,
							HANDCURSOR 	= LM.getSystemCursor("hand"),
							SELECTED	= false,
							IMAGE		= (imagePath) and loadTransparent(imagePath, 0, 0, 0) or nil,
							IMAGECOLOR	= {1,1,1,1},
							TEXTOVER	= "",
							BOXSIZE 	= 32,
							LINE		= {1,1,1,1},
							TEXTCOLOR	= {1,1,1,1}
							
						}, 	{ __index = BOUTTON })
--
end


BOUTTON.onClick = function() end

--

--
BOUTTON.Update = function(self)
--
	--
	self.TEXTOVER = self:Collided() and self.TEXT or ""
	--
--
end

--
BOUTTON.Draw = function(self)
--
	--
	local posX = self.POSITION.x
	local posY = self.POSITION.y
	--
	LG.setColor(unpack(self.TEXTCOLOR))
	LG.print(self.TEXTOVER, posX, posY - 32)	
	--
	if (self.IMAGE) then
	--
		--
		LG.setColor(unpack(self.IMAGECOLOR))
		LG.draw(self.IMAGE, self.POSITION.x, self.POSITION.y)
		--
	--
	end
	--	
	DrawBoxLine(posX, posY,	self.BOXSIZE, self.BOXSIZE, self.LINE)
	--
--
end

--
BOUTTON.MousePressed = function(self, mx, my, button, istouch)
--
	--
	if not self:Collided() then return end	
	--
	if button == 1 then	
	--
		self.SELECTED = not (self.SELECTED)
		self.onClick()
	--
	end
	--	
--
end

--
BOUTTON.Collided = function(self)
--
	
	local CheckCollision = function (x1,y1,w1,h1, x2,y2,w2,h2)
	
	  return x1 < x2+w2 and
			 x2 < x1+w1 and
			 y1 < y2+h2 and
			 y2 < y1+h1
	
	end
	

	local AABB = CheckCollision(LM.getX(), LM.getY(), 1, 1, 
								self.POSITION.x, self.POSITION.y, 
								self.BOXSIZE, self.BOXSIZE)
	
	if AABB then LM.setCursor(self.HANDCURSOR) end
	
	return AABB
--
end


