
--
-- Module Amstrad CPC
--

CPC	   				= {}

--
-- 27 couleurs max (IMPORTANT : doit être immédiatement sous  CPC = {})
--
CPC.BLACK 			= { 0 , 0 , 0 ,1} --  0
CPC.BLUE			= { 0 , 0 ,.5 ,1} --  1
CPC.BRIGHTBLUE 		= { 0 , 0 , 1 ,1} --  2
CPC.RED				= {.5 , 0 , 0 ,1} --  3
CPC.MAGENTA 		= {.5 , 0 ,.5 ,1} --  4
CPC.MAUVE			= {.5 , 0 , 1 ,1} --  5
CPC.BRIGHTRED 		= { 1 , 0 , 0 ,1} --  6
CPC.PURPLE 			= { 1 , 0 ,.5 ,1} --  7
CPC.BRIGHTMARGENTA  = { 1 , 0 , 1 ,1} --  8
CPC.GREEN 			= { 0 ,.5 , 0 ,1} --  9
CPC.CYAN 			= { 0 ,.5 ,.5 ,1} -- 10
CPC.SKYBLUE	 		= { 0 ,.5 , 1 ,1} -- 11
CPC.YELLO 			= {.5 ,.5 , 0 ,1} -- 12
CPC.WHITE 			= {.5 ,.5 ,.5 ,1} -- 13
CPC.PASTELBLUE	 	= {.5 ,.5 , 1 ,1} -- 14
CPC.ORANGE	 		= { 1 ,.5 , 0 ,1} -- 15
CPC.PINK 			= { 1 ,.5 ,.5 ,1} -- 16
CPC.PASTELMAGENTA	= { 1 ,.5 , 1 ,1} -- 17
CPC.BRIGHTGREEN 	= { 0 , 1 , 0 ,1} -- 18
CPC.SEAGREEN  		= { 0 , 1 ,.5 ,1} -- 19
CPC.BRIGHTCYAN	 	= { 0 , 1 , 1 ,1} -- 20
CPC.LIMEGREEN 		= {.5 , 1 , 0 ,1} -- 21
CPC.PASTELGREEN		= {.5 , 1 ,.5 ,1} -- 22
CPC.PASTELCYAN 		= {.5 , 1 , 1 ,1} -- 23
CPC.BRIGHTYELLO 	= { 1 , 1 , 0 ,1} -- 24
CPC.PASTELYELLO  	= { 1 , 1 ,.5 ,1} -- 25
CPC.BRIGHTWHITE 	= { 1 , 1 , 1 ,1} -- 26


CPC.M0 				= {}
CPC.M0.SCREENSIZE	= {x=160, y=200}

CPC.SCREEN			= {}

CPC.PALETTE 		= {}
CPC.PALTGA	 		= {}
CPC.PALSFT			= {}

--
-- Correspondance couleurs software
--
CPC.PALSFT["0001"]	=  { 0, 20} -- Noir
CPC.PALSFT["0051"]	=  { 1,  4} -- Bleu
CPC.PALSFT["0011"]	=  { 2, 21} -- Bleu Vif
CPC.PALSFT["5001"]	=  { 3, 28} -- Rouge
CPC.PALSFT["5051"]	=  { 4, 24} -- Magenta
CPC.PALSFT["5011"]	=  { 5, 29} -- Mauve
CPC.PALSFT["1001"]	=  { 6, 12} -- Rouge Vif
CPC.PALSFT["1051"]	=  { 7,  5} -- Violet
CPC.PALSFT["1011"]	=  { 8, 13} -- Magenta Vif	
CPC.PALSFT["0501"]	=  { 9, 22} -- Vert
CPC.PALSFT["0551"]	=  {10,  6} -- Turquoise
CPC.PALSFT["0511"]	=  {11, 23} -- Bleu Ciel
CPC.PALSFT["5501"]	=  {12, 30} -- Jaune
CPC.PALSFT["5551"]	=  {13,  0} -- Blanc
CPC.PALSFT["5511"]	=  {14, 31} -- Bleu Pastel
CPC.PALSFT["1501"]	=  {15, 14} -- Orange
CPC.PALSFT["1551"]	=  {16,  7} -- Rose
CPC.PALSFT["1511"]	=  {17, 15} -- Magenta Paste
CPC.PALSFT["0101"]	=  {18, 18} -- Vert Vif	
CPC.PALSFT["0151"]	=  {19,  2} -- Vert Marin
CPC.PALSFT["0111"]	=  {20, 19} -- Turquoise Vif
CPC.PALSFT["5101"]	=  {21, 26} -- Vert Citron
CPC.PALSFT["5151"]	=  {22, 25} -- Vert Pastel
CPC.PALSFT["5111"]	=  {23, 27} -- Turquoise Pastel
CPC.PALSFT["1101"]	=  {24, 10} -- Jaune Vif
CPC.PALSFT["1151"]	=  {25,  3} -- Jaune Pastel
CPC.PALSFT["1111"]	=  {26, 11}	-- Blanc Brillant

--
-- 16 couleurs standard
--
CPC.PALETTE[1]  = CPC.BLUE
CPC.PALETTE[2]  = CPC.BRIGHTYELLO
CPC.PALETTE[3]  = CPC.BRIGHTCYAN
CPC.PALETTE[4]  = CPC.BRIGHTRED
CPC.PALETTE[5]  = CPC.BRIGHTWHITE
CPC.PALETTE[6]  = CPC.BLACK
CPC.PALETTE[7]  = CPC.BRIGHTBLUE
CPC.PALETTE[8]  = CPC.BRIGHTMARGENTA
CPC.PALETTE[9]  = CPC.CYAN
CPC.PALETTE[10] = CPC.YELLO
CPC.PALETTE[11] = CPC.PASTELBLUE
CPC.PALETTE[12] = CPC.PINK
CPC.PALETTE[13] = CPC.BRIGHTGREEN
CPC.PALETTE[14] = CPC.PASTELGREEN
CPC.PALETTE[15] = CPC.BLUE
CPC.PALETTE[16] = CPC.SKYBLUE

-- Autres couleurs compatibilité indexation image TGA
CPC.PALETTE[17] = CPC.PASTELMAGENTA
CPC.PALETTE[18] = CPC.MAUVE
CPC.PALETTE[19] = CPC.MAGENTA
CPC.PALETTE[20] = CPC.RED
CPC.PALETTE[21] = CPC.PURPLE
CPC.PALETTE[22] = CPC.GREEN
CPC.PALETTE[23] = CPC.WHITE
CPC.PALETTE[24] = CPC.ORANGE
CPC.PALETTE[25] = CPC.SEAGREEN
CPC.PALETTE[26] = CPC.LIMEGREEN
CPC.PALETTE[27] = CPC.PASTELCYAN
CPC.PALETTE[28] = CPC.PASTELYELLO

--
-- PALETTE TGA
--
CPC.PALTGA["0051"] =  1	-- CPC.BLUE
CPC.PALTGA["0111"] =  3 -- CPC.BRIGHTCYAN
CPC.PALTGA["1001"] =  4 -- CPC.BRIGHTRED
CPC.PALTGA["1111"] =  5 -- CPC.BRIGHTWHITE
CPC.PALTGA["0001"] =  6 -- CPC.BLACK
CPC.PALTGA["0011"] =  7 -- CPC.BRIGHTBLUE
CPC.PALTGA["1011"] =  8 -- CPC.BRIGHTMARGENTA

-- Les teintes jaune
CPC.PALTGA["1101"] =  2 -- CPC.BRIGHTYELLO
CPC.PALTGA["5501"] = 10 -- CPC.YELLO
CPC.PALTGA["1151"] = 28 -- CPC.PASTELYELLO

-- 
CPC.PALTGA["5511"] = 11 -- CPC.PASTELBLUE
CPC.PALTGA["1551"] = 12 -- CPC.PINK
CPC.PALTGA["0101"] = 13 -- CPC.BRIGHTGREEN
CPC.PALTGA["5151"] = 14 -- CPC.PASTELGREEN
CPC.PALTGA["0511"] = 16 -- CPC.SKYBLUE--
CPC.PALTGA["0551"] =  9 -- CPC.CYAN
CPC.PALTGA["5011"] = 18 -- CPC.MAUVE
CPC.PALTGA["1511"] = 17 --  PASTELMAGENTA
CPC.PALTGA["5051"] = 19 --  MAGENTA
CPC.PALTGA["5001"] = 20 --  RED
CPC.PALTGA["1051"] = 21 --  PURPLE
CPC.PALTGA["0501"] = 22 --  GREEN
CPC.PALTGA["5551"] = 23 --  WHITE
CPC.PALTGA["1501"] = 24 --  ORANGE
CPC.PALTGA["0151"] = 25 --  SEAGREEN
CPC.PALTGA["5101"] = 26 --  LIMEGREEN
CPC.PALTGA["5111"] = 27 --  PASTELCYAN

