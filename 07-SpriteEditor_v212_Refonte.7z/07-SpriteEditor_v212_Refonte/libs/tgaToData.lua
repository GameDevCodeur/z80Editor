--
-- tgaToData
--

tgaToData =  function(fileName, arrData, arrPalette)
--
	local width  = #arrData[1]
    local height = #arrData
		
	-- convertir la composante en couleur cpc
	local toComposante = function(c)
	--
		if (c == 0) then return 0 end
		return (c > 127) and 1 or 5
	--
	end
	
	-- convertire bgra en rgba
	local torgba = function(b, g, r, a)
	--			
		_r = toComposante(r)
		_g = toComposante(g)
		_b = toComposante(b)
		_a = toComposante(a)
		
		-- retourne couleur format text "bgra" ex: "1051"
		return _r.._g.._b.._a
	--
	end
	
	--
	file = io.open("zedScr"..".tga", "rb")
	
	--	si ouverture fichier retour
	if file == nil then return end
	
	-- lecture du header tga
	local bytes = file:read(18) -- 18 bytes header	
	
	-- lecture des data
	for rows = 1, height do
	--
		 for cols = 1, width do
		 --			
			local b = string.byte(file:read(1)) -- 1 bytes
			local g = string.byte(file:read(1)) -- 1 bytes
			local r = string.byte(file:read(1)) -- 1 bytes
			local a = string.byte(file:read(1)) -- 1 bytes
			--
			local rgba = torgba(b,g,r,a)
			local indx = arrPalette[rgba] or 1	-- si couleur absente
			--
			arrData[rows][cols] = indx
		--
		end
	--
	end
	--
	file:close()
--	
end