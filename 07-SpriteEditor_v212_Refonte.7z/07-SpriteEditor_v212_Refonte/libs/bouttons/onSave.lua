
--
-- onSave Editeur
--

onSave = function()
--
	--
	idxPalette(CPC.PALETTE, GR.arrCOLORINDEX)
	--
	if (countColors() < 17) then toFileOCR("zedScr", GR.arrCOLORINDEX) end
	--
	toFileTGA("zedScr", GR.arrCOLORINDEX, CPC.PALETTE)
	--
--
end
