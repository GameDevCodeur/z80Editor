--
-- onGomme
--

onGomme = function()
--
	--
	GO.LINE 	  = (GO.SELECTED) and {1,0,1,1} or {1,1,1,1}
	GO.IMAGECOLOR = (GO.SELECTED) and {0,1,0,1} or {1,1,1,1}
	GR.onClick 	  = (GO.SELECTED) and onEriseColor or onSetColor
	--
--
end