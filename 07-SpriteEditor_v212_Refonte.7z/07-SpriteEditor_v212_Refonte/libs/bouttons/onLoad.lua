
--
-- onLoad Editeur
--

onLoad = function()
--
	-- 
	loadPalette("PAL", CPC.PALETTE)
	--
	tgaToData("zedScr", GR.arrCOLORINDEX, CPC.PALTGA)
	--
	idxPalette(CPC.PALETTE, GR.arrCOLORINDEX)
	--
--
end
