
--
-- onExport
--

onExport = function()
--
	exportPalette(CPC.PALETTE, CPC.PALSFT, 16)
--
end